# Qwen Analysis

Provider: Qwen
Model: unknown
Job ID: 2cb2734e-a39e-479e-9ca1-90109ceeb6ec
Started: 2026-08-19T08:23:07.692Z
Completed: 2026-08-19T08:35:14.866Z

---
Independent review statement
[INFERENCE] This review is based only on the provided facts and the stated constraints. I do not have repository access and I am not claiming to have inspected code.
[PROVIDED FACT] Baseline: 837/837 JUnit, 79/79 GameTests, build PASS, plus a new pre-gate production GameTest with two Routing Controllers on one SECURED profile, making GameTests 80/80.
Legend
PROVIDED FACT: directly given in the prompt.
INFERENCE: logical conclusion from provided facts.
DESIGN RECOMMENDATION: what Round 12 should do.
NEEDS REPO VERIFICATION: implementation detail that must be confirmed in code before relying on it.
1. Which model should Round 12 use, and why?
[DESIGN RECOMMENDATION] Round 12 should use Model C, with Model A as the only persistent mechanical core.
In other words:
HUB is a user-facing provisioning/template operation.
The operation performs one authorized atomic batch.
The batch persists only exact Q3 anchor-member edges.
After commit, no persistent HUB policy object remains.
[PROVIDED FACT] Q3 QuantumTopologyRegistry SavedData is the sole authority for profile/lane/endpoint identity and exact undirected sparse edge intent.
[PROVIDED FACT] The lane already supports arbitrary endpoint count and exact edge list.
[PROVIDED FACT] The reconciler is stateless O(E), load-order tolerant, idempotent, and calls existing GridHelper.createConnection.
[INFERENCE] Model A is the only candidate that naturally preserves Q3 as the sole topology authority.
[INFERENCE] Model C is Model A plus a production UX wrapper. It gives users a “create HUB” flow without making HUB a persistent runtime object.
[INFERENCE] Model B creates a second possible source of topology truth: the logical HUB policy and the exact edge list. Even if the conflict rule is defined, the existence of two representations creates accidental complexity and split-brain risk.
[DESIGN RECOMMENDATION] Reject Model B for Round 12 unless it is reduced to a non-authoritative projection of exact edges. If a “HUB” concept persists, it must be metadata-only and must not drive reconciliation.
[DESIGN RECOMMENDATION] If a better model is desired, the only justifiable “D” is:
D-lite: explicit authorized edge-set ticket plus audit receipt.
A one-time ephemeral authoring object carries explicit anchor/lane/member intent into Q4/Q3, is consumed atomically, and leaves only exact edges and optionally a non-authoritative audit receipt.
[INFERENCE] D-lite is not a different persistent model; it is a safer transport for Model A/C authoring intent.
2. How is the Q3 exact-edge invariant preserved? Can policy be added without duplicated truth? If policy exists, what wins on conflict?
[PROVIDED FACT] Q3 SavedData is the sole authority for exact undirected sparse edge intent.
[DESIGN RECOMMENDATION] The exact-edge invariant must be preserved by making the HUB operation write only edge intent:
For a HUB with anchor A and members M1..Mk, persist exactly the edge set {A-M1, A-M2, ..., A-Mk} and nothing else.
[DESIGN RECOMMENDATION] Do not persist a HUB object such as:
text
1
2
3
4
5
Hub {
  mode
  anchor
  members
}
as a topology authority.
[INFERENCE] If such an object can command edge creation, deletion, repair, or status interpretation, it is duplicated truth.
[DESIGN RECOMMENDATION] Policy may be added safely only in one of these forms:
Ephemeral authoring policy
Exists only during validation/commit, discarded afterward.
Non-authoritative audit receipt
Records what the user asked for, but reconciler ignores it.
Derived read-only projection
UI may infer “this looks like a star” from exact edges, but the inference must never rewrite topology or select an anchor automatically.
[DESIGN RECOMMENDATION] If any persistent policy exists anyway, the conflict rule must be:
Exact Q3 edges win unconditionally.
[DESIGN RECOMMENDATION] If policy and exact edges disagree:
The policy must be treated as stale or invalid.
The system must not auto-correct edges from policy.
Repair must not restore policy by changing Q3 edges.
A new explicit authorized operation must be required to change topology.
[INFERENCE] If policy cannot be made strictly subordinate, Model B should be blocked for Round 12.
3. Must anchor identity be persisted separately, or are exact star edges sufficient? What happens on anchor unload/destruction? Should replacement ever be automatic now?
Anchor persistence
[DESIGN RECOMMENDATION] Anchor identity must be explicit in the authoring request, but it does not need to be persisted as a separate authoritative HUB field.
[INFERENCE] Exact star edges are sufficient for topology authority:
If edge A-M1 exists, A is topologically connected to M1.
If edge A-M2 exists, A is topologically connected to M2.
No additional “anchor object” is required for the graph to be correct.
[DESIGN RECOMMENDATION] If anchor identity is stored at all, store it only as:
an audit receipt field, or
a non-authoritative UI hint, or
a derived visualization label.
[DESIGN RECOMMENDATION] Do not allow any runtime system to choose an anchor by:
first activation,
registration order,
UUID sort,
load order,
BlockPos,
highest degree,
lowest endpoint ID,
credential order,
or any other implicit rule.
[PROVIDED FACT] BlockPos is not identity; cards are not authoritative.
[INFERENCE] Therefore BlockPos may be used only as a player-interaction convenience, never as persistent anchor identity.
Anchor unload
[DESIGN RECOMMENDATION] If the anchor is unloaded:
All edges incident to the anchor become operationally degraded/unavailable.
The exact edge intent remains persistent unless explicitly removed by an authorized operation.
Members do not connect to each other.
No alternate route is invented.
No replacement anchor is selected.
[PROVIDED FACT] Runtime presence, materialized GridConnections, and operational status are not persistent authority.
[INFERENCE] Therefore an unloaded anchor should not erase persistent edge intent merely because the chunk is absent.
Anchor destruction
[DESIGN RECOMMENDATION] If the anchor endpoint is destroyed or its identity is revoked:
All anchor-member edges become unserviceable.
The HUB degrades to isolated members.
No member-member edges are implicitly created.
No member is promoted to anchor.
No automatic rewire occurs.
[NEEDS REPO VERIFICATION] What exactly happens to endpoint identity when the owning block entity is destroyed: whether identity remains dormant, is revoked, or is garbage-collected.
[DESIGN RECOMMENDATION] Regardless of the lifecycle detail, destruction must not cause silent rewire.
Automatic anchor replacement
[DESIGN RECOMMENDATION] No automatic anchor replacement in Round 12.
[PROVIDED FACT] Round 12 excludes automatic failover/anchor replacement.
[INFERENCE] Automatic replacement would require policy, intent, and topology mutation, which would violate the Round 12 boundary and the explicit-anchor rule.
4. Who may author HUB topology? How can production UX preserve BUILD/Q4 authorization without restoring QUANTUM_ROUTE-only Controller CREATE?
[PROVIDED FACT] Round 11 deliberately removed Controller topology CREATE/DELETE because QUANTUM_ROUTE alone bypassed the BUILD/Q4 authoring boundary.
[PROVIDED FACT] Current Routing Controller is SECURED-profile-local, stateless VIEW plus QUANTUM_ROUTE repair of existing intent only.
[DESIGN RECOMMENDATION] HUB topology may only be authored by an actor satisfying:
BUILD authorization, and
Q4/security-domain authorization for the target SECURED profile/lane, and
explicit selection of anchor and members.
[DESIGN RECOMMENDATION] The Routing Controller must not become the authoring authority.
[DESIGN RECOMMENDATION] The safe division is:
Q4/provisioning service: authoritative validation and atomic Q3 edge commit.
Routing Controller: optional viewer/initiator only.
QUANTUM_ROUTE: repair/status only, never CREATE/DELETE.
[INFERENCE] A Controller UI can preserve the Round 11 boundary if it is merely a thin client that submits a request to Q4, and the server-side Q4 operation enforces BUILD.
[DESIGN RECOMMENDATION] Do not expose a Controller method conceptually named or treated as Controller.createHub. If a Controller UI initiates HUB creation, it should call a Q4 provisioning API, and the Controller itself should remain stateless with respect to topology intent.
[NEEDS REPO VERIFICATION] Whether permission checks for BUILD/Q4/QUANTUM_ROUTE are enforced server-side and cannot be bypassed by client UI state.
5. Given current cards lack lane/anchor selection, evaluate narrow production flows
[PROVIDED FACT] Current credential-card data has no lane/anchor selector.
[PROVIDED FACT] Cards are not authoritative.
Flow (i): annotate each issued member credential card with a non-authoritative target anchor/lane hint, revalidated on activation
[INFERENCE] This flow can be safe only if the hint is strictly advisory.
[DESIGN RECOMMENDATION] Card hints may be used only to populate an explicit authorized draft. They must not automatically write Q3 edges on activation.
Risks
[INFERENCE] If activation automatically adds an edge from a card hint, the card hint becomes de facto topology authority.
[INFERENCE] Sequential activation of hinted cards is not atomic for N-member HUBs. It can leave partial stars if one activation fails after earlier edges were written.
[INFERENCE] Stale hints can point to destroyed anchors, wrong lanes, wrong profiles, revoked credentials, or legacy endpoints.
Conditions for accepting card hints
[DESIGN RECOMMENDATION] If card hints are used:
The hint must be non-authoritative.
The hint must be revalidated against Q3 identity, profile, lane, security domain, credential status, and BUILD/Q4 authorization.
The hint must not cause edge creation by itself.
The final HUB commit must be one atomic operation.
A stale or conflicting hint must cause rejection, not fallback.
[DESIGN RECOMMENDATION] For Round 12, card hints are not sufficient by themselves.
Flow (ii): a Controller action requiring BOTH BUILD and routing permission and invoking Q4
[INFERENCE] This can be acceptable if the Controller is only an initiator and Q4 is the authoritative authoring path.
Acceptable form
[DESIGN RECOMMENDATION] The Controller action must:
require BUILD,
require routing permission only as an additional gate if desired,
invoke Q4 server-side,
perform no direct Q3 mutation,
persist no Controller-owned topology,
not operate under QUANTUM_ROUTE alone,
not restore Round 11’s removed Controller CREATE/DELETE semantics.
Risk
[INFERENCE] Even with dual permission, if the product treats the Controller as the creator, it reintroduces the conceptual mistake Round 11 removed.
[DESIGN RECOMMENDATION] If this flow is used, describe and implement it as:
“Controller opens Q4 HUB provisioning,”
not
“Controller creates HUB.”
Flow (iii): another safer minimal flow
[DESIGN RECOMMENDATION] Use an explicit one-shot Q4/BUILD HUB commit flow, preferably with an ephemeral draft or one-time authorization ticket.
Recommended minimal production flow
[DESIGN RECOMMENDATION]
A player with BUILD permission explicitly selects a SECURED profile/lane through a Q4 provisioning UI or authorized interaction.
The player explicitly designates the anchor endpoint.
The player explicitly adds member endpoints or credential cards to a transient draft.
The draft is server-side only and non-authoritative.
The player commits.
Q4 validates the entire set.
Q3 atomically persists N-1 exact anchor-member edges.
The draft is discarded.
Optional audit receipt is stored non-authoritatively.
[DESIGN RECOMMENDATION] This flow avoids changing card authority and avoids Router authority.
[INFERENCE] This is safer than per-card activation because it is one atomic validation/commit operation.
[DESIGN RECOMMENDATION] If a physical card/ticket is used, it should be a consumable authorization artifact, not a persistent topology authority.
6. Should HUB remain SECURED-only for this round? Is LEGACY HUB necessary?
[PROVIDED FACT] SECURED cross-domain merge is rejected before Grid merge.
[PROVIDED FACT] LEGACY Routing Controller is UNBOUND.
[DESIGN RECOMMENDATION] HUB must remain SECURED-only for Round 12.
[INFERENCE] LEGACY HUB is not necessary because LEGACY lacks the SECURED profile/domain boundary required for safe explicit HUB authoring.
[DESIGN RECOMMENDATION] Do not allow LEGACY endpoints, LEGACY controllers, or UNBOUND legacy routing objects to author HUB topology.
[DESIGN RECOMMENDATION] Do not allow a SECURED HUB to include a LEGACY unbound endpoint unless that endpoint is explicitly represented inside a valid SECURED identity/domain, and even then only after verification.
[NEEDS REPO VERIFICATION] Whether any legacy endpoint can appear inside a SECURED lane or be converted/bound safely.
[DESIGN RECOMMENDATION] If legacy interaction cannot be proven safe, block LEGACY HUB entirely.
[PROVIDED FACT] Vanilla QNB is separate and must not change.
[DESIGN RECOMMENDATION] HUB authoring must not mutate, upgrade, convert, or reroute vanilla QNB behavior.
7. How do topology semantics and Mk II capacity remain independent axes? May Mk I participate in HUB and may tiers mix?
[PROVIDED FACT] CapacityTier is authoritative: STANDARD dense=32, QUANTUM dense=64, SINGULARITY=128, COSMIC=256.
[PROVIDED FACT] Mk I endpoint has one DENSE_CAPACITY STANDARD node.
[PROVIDED FACT] Candidate Mk II reuses the same BE architecture with QUANTUM.
[PROVIDED FACT] Native pathing uses per-node bottlenecks.
[PROVIDED FACT] P2P and Quantum never generate capacity.
Independence
[DESIGN RECOMMENDATION] Keep topology and capacity as separate axes:
Topology axis: exact Q3 edges.
Capacity axis: endpoint/node CapacityTier and native pathing bottlenecks.
[INFERENCE] A HUB edge list should not itself grant channel capacity.
[DESIGN RECOMMENDATION] The HUB operation should not require equal tiers, but it may emit capacity warnings.
Mk I participation
[DESIGN RECOMMENDATION] Mk I endpoints may participate in HUB if:
they have valid SECURED identity,
they pass Q4/BUILD authorization,
they are explicitly included,
their pair-specific provisioning does not interfere,
and capacity degradation is accepted.
[INFERENCE] Mk I endpoints will usually be capacity bottlenecks because they have STANDARD dense capacity.
Tier mixing
[DESIGN RECOMMENDATION] Tiers may mix topologically, but effective transport must be limited by the weakest endpoint/node in the path.
Example:
[INFERENCE] If a Mk I STANDARD member connects to a Mk II QUANTUM anchor, the member-side capability remains STANDARD. The QUANTUM anchor does not elevate the Mk I endpoint.
[DESIGN RECOMMENDATION] For production sanity, a HUB anchor should usually be Mk II/QUANTUM or better, but this should be a validation warning or product rule, not an implicit topology rule.
[NEEDS REPO VERIFICATION] Whether current pathing correctly applies mixed-tier endpoint bottlenecks for all HUB paths.
8. For Mk I↔Mk II, should effective edge transport be min of both endpoint capabilities through native pathing, or require a separate transport object? Explain channel-generation risks.
[DESIGN RECOMMENDATION] Use native pathing with effective transport bounded by endpoint/node capabilities. Do not introduce a separate HUB transport object.
[INFERENCE] Effective transport for a path should be constrained by the minimum capability of the participating endpoint nodes and existing path bottlenecks.
For a path:
text
1
Member Mk I -> Anchor Mk II -> Member Mk II
[INFERENCE] The path must not gain capacity merely because the anchor is QUANTUM. The Mk I member remains limited by its STANDARD node.
Why not a separate transport object?
[INFERENCE] A separate transport object risks becoming a magical bus with its own channel pool.
Risks:
Channel generation
The object may appear to provide channels that are not backed by real endpoint nodes.
Capacity multiplication
A QUANTUM anchor with 99 edges could be misread as 99 × 64 capacity.
Duplicate authority
The transport object could become a second source of truth for connectivity or capacity.
Bottleneck bypass
Paths could skip upstream controller/cable/P2P constraints.
[PROVIDED FACT] P2P and Quantum never generate capacity.
[DESIGN RECOMMENDATION] Therefore, no HUB edge, HUB object, or HUB transport object may create channel capacity.
[DESIGN RECOMMENDATION] If native pathing cannot express the needed limitation without a new object, that is a blocking implementation issue.
[NEEDS REPO VERIFICATION] Whether native pathing can already represent quantum/HUB adjacency without assigning edge-local channel capacity.
9. How should a star avoid a magical 64×edges capacity pool and preserve upstream/controller/cable/P2P/downstream bottlenecks?
[DESIGN RECOMMENDATION] Treat the star as a set of exact adjacency edges, not as a central capacity pool.
Forbidden model
[DESIGN RECOMMENDATION] Do not model HUB as:
text
1
HUB backplane capacity = anchor capacity × number of edges
or:
text
1
each edge grants 64 channels
[INFERENCE] That would create a magical 64×edges pool and violate the rule that Quantum never generates capacity.
Recommended model
[DESIGN RECOMMENDATION] Capacity must be evaluated per path through real nodes:
text
1
member endpoint node -> anchor endpoint node -> member endpoint node
plus any local grid nodes, controllers, cables, P2P tunnels, or downstream endpoints traversed by the path.
[PROVIDED FACT] Native pathing uses per-node bottlenecks.
[DESIGN RECOMMENDATION] The anchor’s capacity is a shared node bottleneck, not a per-edge allocation.
Example:
[INFERENCE] If the anchor is QUANTUM dense=64, the anchor may contribute a 64-channel bottleneck, but it does not provide 64 channels independently to each of 99 members.
[DESIGN RECOMMENDATION] The pathfinder/accounting must respect:
member endpoint node capacity,
anchor endpoint node capacity,
controller capacity,
cable capacity,
P2P capacity constraints,
downstream device/node constraints,
and any existing grid topology bottlenecks.
[DESIGN RECOMMENDATION] HUB exact edges should influence adjacency/reachability, not create new capacity.
10. Define atomic validation/rollback for N-1 authoring
[DESIGN RECOMMENDATION] Round 12 should implement a server-side atomic HUB authoring operation.
Request shape
[DESIGN RECOMMENDATION] The authoring request should contain:
text
1
2
3
4
5
6
7
8
9
HubAuthoringRequest {
  actor security context
  NetworkProfileId
  SecurityDomainId
  QuantumLaneId
  anchorEndpointId
  memberEndpointIds[]
  credential bindings[]
}
[DESIGN RECOMMENDATION] The request must not infer anchor from order, BlockPos, UUID sort, load order, or first activation.
Atomic commit model
[DESIGN RECOMMENDATION] Use a copy-on-write or staged snapshot model:
Read current lane/endpoint/credential state.
Build candidate final edge set.
Validate entire candidate.
If invalid, discard candidate.
If valid, atomically replace/commit candidate edge set.
Mark SavedData dirty only after successful commit.
Allow reconciler to materialize connections afterward.
[DESIGN RECOMMENDATION] Do not create materialized GridConnections during validation.
[INFERENCE] If runtime materialization is part of the commit, a chunk-unloaded member could cause partial success. Materialization must be edge-local and post-commit.
Validation rules
Actor authorization
[DESIGN RECOMMENDATION] Reject unless actor has:
BUILD permission,
Q4 authorization for the target SECURED profile/domain/lane,
and operation occurs on the correct server thread/context.
[NEEDS REPO VERIFICATION] Exact permission APIs and whether BUILD/Q4 checks are centralized.
Profile/domain/lane checks
[DESIGN RECOMMENDATION] Reject if:
profile is not SECURED,
lane does not belong to profile,
security domain mismatches,
endpoint belongs to wrong profile,
endpoint belongs to wrong lane,
endpoint is legacy/unbound where not allowed,
endpoint is vanilla QNB where not allowed.
[PROVIDED FACT] SECURED cross-domain merge is rejected before Grid merge.
Anchor checks
[DESIGN RECOMMENDATION] Reject if:
anchor is not explicitly provided,
anchor endpoint identity is invalid,
anchor credential is invalid,
anchor is revoked/suspended,
anchor appears in member list,
anchor is not authorized for the lane/domain/profile.
Member checks
[DESIGN RECOMMENDATION] Reject if:
member list is empty where HUB requires members,
duplicate member endpoint IDs appear,
duplicate credential bindings appear,
a member is invalid,
a member is revoked/suspended,
a member belongs to another profile/domain,
a member is already conflicting with strict star intent.
Star integrity checks
[DESIGN RECOMMENDATION] For strict HUB authoring, reject if the lane already contains conflicting edges among the selected endpoints, unless the operation explicitly authorizes removals/replacements.
Examples:
existing member-member edge,
existing member-other-anchor edge,
existing edge that would make the final graph non-star,
unknown edge involving the same endpoint set in the same lane.
[DESIGN RECOMMENDATION] If Round 12 wants minimal additive behavior instead of strict replacement, the operation must be named accordingly, e.g. “ensure anchor edges,” not “create HUB.”
Credential conflict checks
[DESIGN RECOMMENDATION] Reject if:
credential is unknown,
credential is revoked,
credential is suspended,
credential is already bound incompatibly,
two members present the same credential for different endpoints,
credential domain does not match endpoint/domain/profile,
credential card hint conflicts with Q3 identity.
[PROVIDED FACT] Cards are not authoritative.
[INFERENCE] Therefore credential validation must use Q3/security identity, not item NBT alone.
Failure after some edge writes
[DESIGN RECOMMENDATION] This must be impossible by construction.
Preferred implementation:
[DESIGN RECOMMENDATION] Copy-on-write:
text
1
2
3
4
5
candidate = snapshot(current lane edge set)
validate(request, candidate)
apply(candidate, N-1 edge additions)
validateFinal(candidate)
commit(candidate)
If any step fails, discard candidate. No partial persistent mutation occurs.
[NEEDS REPO VERIFICATION] Whether QuantumTopologyRegistry SavedData can be safely cloned/replaced or whether it must be mutated in place.
If in-place mutation is unavoidable:
[DESIGN RECOMMENDATION] Use an undo log:
Record inverse operation for every edge addition/removal.
Apply mutations only after full validation.
On exception, apply inverse operations in reverse.
Revalidate restored state.
Do not mark dirty if rollback succeeds.
[INFERENCE] Undo-log mutation is weaker than copy-on-write and should be avoided if possible.
Duplicate edge behavior
[DESIGN RECOMMENDATION] If a requested anchor-member edge already exists:
treat it as idempotent success for that edge,
do not create duplicate edge records,
still validate the whole request,
still require atomic success for missing edges.
Orphan prevention
[DESIGN RECOMMENDATION] The operation must not persist an edge unless both endpoint identities are valid or created atomically in the same authorized batch.
[DESIGN RECOMMENDATION] If endpoint identity creation is part of the operation, identity creation and edge creation must share the same atomic commit/rollback.
[DESIGN RECOMMENDATION] If endpoints must already exist, then missing endpoint identity is a validation failure.
11. Define edge-local failure for one unloaded/revoked/suspended/cross-domain member while healthy edges remain
[DESIGN RECOMMENDATION] Failure must be edge-local, not HUB-global.
General rule
[DESIGN RECOMMENDATION] Persistent exact edge intent remains unchanged unless an explicit authorized operation changes it. Operational status is derived.
[PROVIDED FACT] Runtime presence, materialized GridConnections, and operational status are not persistent authority.
Unloaded member
[DESIGN RECOMMENDATION] If one member is unloaded:
the anchor-member edge for that member is operationally DOWN/UNLOADED,
other healthy anchor-member edges remain active if materializable,
no rewire occurs,
no alternate member is used,
when the member loads, reconciler idempotently materializes the edge.
[INFERENCE] Because the reconciler is load-order tolerant, unloaded endpoints should not invalidate persistent intent.
Revoked credential
[DESIGN RECOMMENDATION] If a member credential is revoked:
the affected edge is operationally INHIBITED/REVOKED,
no GridConnection should be created or maintained for that edge,
other edges remain unaffected,
persistent edge intent may remain for audit, but it must be inert,
permanent cleanup should require explicit authorized deletion.
[NEEDS REPO VERIFICATION] Whether the current reconciler can suppress or remove a materialized connection for a revoked edge without deleting persistent intent.
Suspended credential
[DESIGN RECOMMENDATION] If a member credential is suspended:
affected edge is operationally SUSPENDED,
edge intent persists,
no materialization occurs while suspended,
healthy edges remain active.
Cross-domain member
[DESIGN RECOMMENDATION] If a member becomes cross-domain or is discovered to be cross-domain:
affected edge is operationally DOMAIN_MISMATCH/INHIBITED,
no Grid merge may occur through that edge,
healthy same-domain edges remain active,
no fallback path may bypass domain separation.
[PROVIDED FACT] SECURED cross-domain merge is rejected before Grid merge.
Anchor failure
[DESIGN RECOMMENDATION] If the anchor is unloaded/revoked/suspended/cross-domain:
all edges incident to the anchor are degraded/inhibited,
member-member connectivity is not created,
no automatic anchor replacement occurs.
[INFERENCE] This is the correct behavior because HUB is not a failover policy in Round 12.
12. Show O(N)/O(E), including 100 endpoints → 99 exact edges, not 4950
[PROVIDED FACT] Reconciler is stateless O(E).
[INFERENCE] A star with N endpoints has:
text
1
E = N - 1
[INFERENCE] For 100 endpoints:
text
1
2
N = 100
E =
[INFERENCE] A full mesh would be:
text
1
N * (N - 1) / 2 = 100 * 99 / 2 = 4950
[DESIGN RECOMMENDATION] HUB authoring and reconciliation must remain star-sparse, not mesh-complete.
Authoring complexity
[DESIGN RECOMMENDATION] Use hash sets for member uniqueness:
duplicate member detection: O(N)
anchor-in-member check: O(N)
edge construction: O(N - 1)
existing-edge conflict scan: O(E_lane)
For a fresh HUB lane:
text
1
E_lane ≈ N - 1
For an existing lane:
text
1
total ≈ O(E_lane + N)
[DESIGN RECOMMENDATION] Do not validate by checking every possible member pair. That would be O(N²) and could accidentally imply mesh semantics.
Reconciliation complexity
[INFERENCE] Since the persisted edge list has E edges, reconciliation remains O(E).
For 100-endpoint HUB:
text
1
E = 9
not 4950.
Status/repair complexity
[PROVIDED FACT] Round 11 status/repair validation is pair-hardcoded.
[DESIGN RECOMMENDATION] Before enabling 3+ endpoint HUBs in production, status/repair validation must be generalized to iterate exact edges:
text
1
2
for edge in lane.edges:
    validate/status(edge)
[DESIGN RECOMMENDATION] Do not add pair-only assumptions such as “lane has exactly two endpoints” or “edge 0 is member A and edge 1 is member B.”
13. Mandatory adversarial 3–5 endpoint and restart/load-order tests
[DESIGN RECOMMENDATION] The following tests should be mandatory before Round 12 HUB is accepted.
T1: HUB-3 basic explicit anchor
[DESIGN RECOMMENDATION] Create a 3-endpoint HUB:
text
1
Assert:
exactly two persistent edges exist: A-B, A-C,
no B-C edge exists,
anchor was the explicitly selected endpoint,
no UUID sort/load order/BlockPos selected anchor,
Router did not create topology,
reconciler materializes only the two exact edges.
T2: HUB-3 anchor loaded last
[DESIGN RECOMMENDATION] Persist a 3-endpoint HUB, restart/reload with members loaded before anchor.
Assert:
no duplicate edges,
no partial edges,
no implicit member-member edge,
reconciler converges to exact intent,
status becomes healthy when anchor loads.
T3: HUB-4 one member unloaded
[DESIGN RECOMMENDATION] Create:
text
1
2
Anchor: A
Members: B, C, D
Unload D.
Assert:
A-B healthy,
A-C healthy,
A-D degraded/unloaded,
no B-C, B-D, or C-D edge appears,
no rewire through B or C,
when D reloads, A-D becomes healthy idempotently.
T4: HUB-5 anchor destruction
[DESIGN RECOMMENDATION] Create:
text
1
2
Anchor: A
Members: B, C, D, E
Destroy or invalidate anchor A.
Assert:
all incident edges become unserviceable/inert,
members do not connect to each other,
no endpoint is promoted,
no replacement anchor is selected,
persistent intent is either cleanly inert or explicitly cleaned by authorized operation,
no silent rewire occurs.
T5: HUB-5 restart/load-order permutations
[DESIGN RECOMMENDATION] Persist a 5-endpoint HUB and restart with adversarial load orders:
anchor first,
anchor last,
members interleaved,
one member missing,
all endpoints loaded after controller/router.
Assert:
exact edge set remains 4 edges,
reconciler remains idempotent,
no duplicate GridConnections,
no orphan edges,
Router is unnecessary for restart.
T6: Authorization negative tests
[DESIGN RECOMMENDATION] Verify all of these are rejected without partial persistence:
QUANTUM_ROUTE-only HUB create,
Controller CREATE without BUILD,
BUILD without Q4/domain authorization,
cross-profile HUB,
cross-domain member,
LEGACY controller authoring,
vanilla QNB endpoint authoring where forbidden,
duplicate member,
anchor included in member list,
missing explicit anchor,
wrong lane,
revoked credential,
suspended credential,
conflicting existing member-member edge in strict HUB mode.
T7: Atomic failure injection
[DESIGN RECOMMENDATION] Inject failure after validation but before commit, or during edge mutation if implementation is in-place.
Assert:
zero persistent edge changes,
zero orphan endpoint identities,
zero partial HUB,
SavedData not marked dirty with partial state,
subsequent retry can succeed cleanly.
[NEEDS REPO VERIFICATION] Whether failure injection hooks exist or must be added.
T8: Mixed-tier capacity test
[DESIGN RECOMMENDATION] Create a HUB with:
Mk II QUANTUM anchor,
Mk I STANDARD member,
Mk II QUANTUM member.
Assert:
Mk I member does not gain QUANTUM capacity,
anchor does not create 64×edges capacity,
native pathing respects per-node bottlenecks,
upstream/controller/cable/P2P/downstream bottlenecks remain enforced.
[NEEDS REPO VERIFICATION] Exact channel accounting assertions available in tests.
T9: Router repair boundary
[DESIGN RECOMMENDATION] With a 3+ endpoint HUB, damage or unload some materialized connections, then allow Router repair.
Assert:
Router repairs existing intent only,
Router does not add missing star edges,
Router does not delete exact edges,
Router does not infer member-member edges,
Router does not select or replace anchor.
14. Blocking STOP conditions and what must remain out of scope
Blocking STOP conditions
[DESIGN RECOMMENDATION] STOP if any of the following occurs.
Partial persistent topology after failed authoring
If a failed HUB operation can leave even one persistent edge or orphan endpoint identity, block.
Implicit anchor selection
If anchor can be chosen by first activation, registration order, UUID sort, load order, BlockPos, credential order, or degree inference, block.
Router becomes authoring authority
If QUANTUM_ROUTE alone or Controller-local state can CREATE/DELETE HUB edges, block.
Persistent HUB policy overrides exact edges
If a HUB object can conflict with Q3 edge intent and cause reconciliation, block.
Split-brain policy/edge divergence
If policy and exact edges can diverge and either can drive behavior, block.
Cross-domain SECURED merge
If HUB edges can cause cross-domain Grid merge before rejection, block.
Automatic anchor replacement or silent rewire
If anchor unload/destruction causes automatic rewire or member promotion, block.
Capacity generation
If HUB edge or HUB object creates channels, capacity pools, or 64×edges behavior, block.
O(N²) star realization
If a 100-endpoint HUB persists or reconciles 4950 edges, block.
Pair-hardcoded status breaks 3+ endpoints
If status/repair validation cannot handle 3–5 endpoint exact edges without pair assumptions, block.
Legacy HUB authoring
If LEGACY/UNBOUND controller can create HUB, block.
Vanilla QNB mutation
If HUB changes vanilla QNB behavior, block.
Card hint authority
If credential-card hints can directly mutate Q3 topology without explicit Q4/BUILD revalidation, block.
Runtime status rewriting persistent intent
If operational status, unload state, or GridConnection presence alters persistent edge intent without explicit authorized operation, block.
Must remain out of scope
[PROVIDED FACT] Round 12 excludes MESH, automatic failover/anchor replacement, alternate routing, Mk III/IV, optimizer, global browser and final power economy.
[DESIGN RECOMMENDATION] Also keep out of Round 12:
automatic HUB discovery,
automatic member-member meshing,
automatic anchor election,
automatic credential rebind,
cross-profile HUB,
LEGACY HUB,
vanilla QNB integration,
P2P capacity generation,
quantum capacity generation,
global topology browser,
optimizer-driven edge rewriting,
final power economy tuning,
Mk III/IV endpoint semantics.
Additional architecture constraints
Suppress implicit pair provisioning during HUB authoring
[PROVIDED FACT] Current production Mk I provisioning is PAIR-specific: BUILD-gated fresh activation finds/creates a lane with fewer than 2 endpoints and auto-adds its one edge when the second endpoint activates.
[INFERENCE] Sequential fresh activation is unsafe for explicit N-member HUB authoring because it can create pair edges before the HUB batch commits.
[DESIGN RECOMMENDATION] HUB authoring must either:
operate only on already-provisioned endpoint identities, or
use an explicit batch endpoint-provisioning path that suppresses implicit pair auto-add, or
create endpoint identities and edges in one atomic authorized batch.
[NEEDS REPO VERIFICATION] Whether the current pair-provisioning path can be suppressed or bypassed safely.
Pair-hardcoded repair must not be reused blindly
[PROVIDED FACT] Round 11 status/repair validation is pair-hardcoded.
[DESIGN RECOMMENDATION] Do not reuse pair-specific repair logic for 3+ endpoint HUBs unless it is generalized to exact-edge iteration.
[INFERENCE] Pair-hardcoded repair could incorrectly expect exactly two endpoints, create missing edges, or misinterpret a star as broken pair state.
NEEDS REPO VERIFICATION checklist
[NEEDS REPO VERIFICATION] Verify all of the following before enabling production HUB:
QuantumTopologyRegistry SavedData can be mutated atomically via copy-on-write or equivalent.
Lane edge lists can be replaced/committed without partial persistence.
Endpoint identity creation can be included in the same atomic batch if needed.
Credential validation can check active/revoked/suspended/domain state server-side.
BUILD/Q4 authorization checks are enforced server-side and cannot be bypassed by Controller UI.
Routing Controller cannot CREATE/DELETE topology through any residual path.
Reconciler can materialize exact star edges without pair assumptions.
Reconciler can suppress or tear down materialized connections for inhibited edges without deleting persistent intent.
Native pathing respects mixed Mk I/Mk II endpoint capacities.
Quantum edges do not add channel capacity independently.
Legacy endpoints/controllers cannot participate in SECURED HUB unless explicitly allowed.
Vanilla QNB remains isolated.
Pair-specific Mk I activation can be prevented from interfering with explicit HUB batches.
Failure injection hooks exist for atomicity tests.
Verdict
[DESIGN RECOMMENDATION] PROCEED WITH CONDITIONS
Round 12 may proceed with production sparse HUB + Mk II only if the following exact conditions are met:
Use Model C/A only
HUB is a provisioning template. The only persistent result is N-1 exact Q3 anchor-member edges.
No persistent HUB authority
No HUB mode, policy, member list, or anchor object may override Q3 exact edges. Any stored metadata must be non-authoritative.
Explicit anchor required
Anchor must come from explicit user intent in the authoring request. No first activation, registration order, UUID sort, load order, BlockPos, or inferred high-degree anchor selection.
Atomic authoring
The HUB operation must validate and commit as one atomic batch. Failed operations must leave no partial edges, no orphan endpoints, and no dirty partial SavedData.
BUILD/Q4 authoring only
HUB creation must require BUILD and Q4/security-domain authorization. QUANTUM_ROUTE alone must never create or delete HUB topology.
Router remains view/repair only
The Routing Controller may display or initiate a Q4 request, but must not be the topology authority and must not restore Round 11’s removed CREATE/DELETE semantics.
SECURED-only HUB
HUB authoring is allowed only for SECURED profiles/domains. LEGACY HUB is not allowed in Round 12.
Edge-local failure semantics
One unloaded/revoked/suspended/cross-domain member must degrade only its edge. Healthy edges remain. No global failover, no rewire, no anchor replacement.
Capacity remains independent
HUB must not generate capacity. Mk I/Mk II mixed paths must be limited by endpoint/node capabilities and native pathing bottlenecks. No 64×edges pool.
O(E) star semantics
A 100-endpoint HUB must persist 99 edges, not 4950. Authoring, reconciliation, and status must avoid O(N²) mesh behavior.
Generalize pair-hardcoded validation
Status/repair validation must handle 3+ endpoint exact stars without pair assumptions.
Mandatory adversarial tests pass
The 3–5 endpoint tests, restart/load-order tests, authorization negative tests, atomic-failure tests, and mixed-capacity tests must pass before release.
Repo verification completes
Atomic SavedData commit, permission enforcement, reconciler edge handling, mixed-tier pathing, and legacy isolation must be verified in the actual implementation.
If any of these conditions cannot be guaranteed, the correct result is BLOCK for production HUB in Round 12.
